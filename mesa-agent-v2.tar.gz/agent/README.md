# MESA agent (`services/agent`)

Writes **incident reports** and **shift reports** for MESA. It never decides or acts: the module's
threshold rules do that. See `docs/AGENT_HANDOFF.md` section 5 and `MODULE_CONTRACT.md`.

## Setup

```bash
cd services/agent
npm install
cp .env.example .env          # .env is git-ignored
# put the Anthropic key in .env as ANTHROPIC_API_KEY=...   (never in code, never committed)
```

## Run

```bash
npm run demo:offline   # no database needed: builds a report for a sample hot-rack incident
npm start              # connects to SpacetimeDB (STDB_HOST / STDB_DB) and reacts to incidents
```

With no `ANTHROPIC_API_KEY`, everything still works and reports come from the template
(`source: "template"`). On first connect the agent prints its identity and token: save the token as
`STDB_AGENT_TOKEN`, and give the identity to the module owner to add to `agent_identity`.

## Deploy (Railway)

New service from this folder, start command `npm start`, variables from `.env.example` with real values
set in Railway's Variables tab. The agent exits on disconnect so Railway restarts it.

## Files

| File | Role |
|---|---|
| `src/index.ts` | Event loop and the agent's behavior statements |
| `src/prompts.ts` | Role, limits and writing instructions for Claude |
| `src/llm.ts` | Claude calls with forced tool output, validation, budget, fallback |
| `src/template.ts` | Deterministic reports when Claude is unavailable |
| `src/aggregate.ts` | Impact numbers and the compact payload the model sees |
| `src/stdb.ts` | The only file that touches generated bindings; fix names here |
| `src/dev/offline-demo.ts` | Sample incident for prompt tuning |
