// Deterministic fallback. Used when there is no API key, Claude times out, the rate limit
// is hit, or Claude's output fails validation. Same fields, built from numbers only.
import type { IncidentContext, IncidentReport, ShiftReport, Incident } from './types.js';
import { computeImpact, hms, latestMigrations } from './aggregate.js';

export function templateIncidentReport(ctx: IncidentContext, kind: 'final' | 'interim'): IncidentReport {
  const i = ctx.incident;
  const impact = computeImpact(ctx);
  const migs = latestMigrations(ctx.migrations);
  const done = migs.filter((m) => m.step === 'done');
  const failed = migs.filter((m) => m.step === 'rolled_back');
  const target = done[0]?.toRack;

  let summary: string;
  if (i.category === 'security') {
    summary = `A honeypot detected hostile activity (${i.triggerRule}) and the caller was quarantined automatically. ` +
      (kind === 'interim' ? `The incident is escalated to ${i.owner}.` : 'No real system state was changed.');
  } else if (kind === 'interim') {
    summary = `Rack ${i.rackId} met the ${i.triggerRule} rule but automation could not finish` +
      (failed.length ? ` (${failed.length} migration${failed.length > 1 ? 's' : ''} rolled back)` : '') +
      `. ${i.owner} now owns the incident.`;
  } else {
    summary = `Rack ${i.rackId} met the ${i.triggerRule} rule and MESA moved ${done.length} service${done.length === 1 ? '' : 's'}` +
      (target ? ` to ${target}` : '') + ` with no downtime. The rack recovered and the incident closed at ${i.closedAt ? hms(i.closedAt) : 'an unrecorded time'}.`;
  }

  const timeline = [
    { ts: hms(i.openedAt), text: `Incident opened on ${i.rackId} (${i.triggerRule}).` },
    ...migs.map((m) => ({ ts: hms(m.stepAt), text: `${m.serviceName}: ${m.fromRack} → ${m.toRack}, ${m.step === 'done' ? 'migrated' : m.step}.` })),
    ...(i.closedAt ? [{ ts: hms(i.closedAt), text: 'Incident closed.' }] : []),
  ].slice(0, 12);

  return {
    summary,
    impact,
    timeline,
    automated_actions: [
      { rule: i.triggerRule, inputs: JSON.stringify(i.triggerInputs), migration_id: null, result: 'fired' },
      ...migs.map((m) => ({ rule: 'live_migration', inputs: `${m.serviceName} ${m.fromRack}→${m.toRack}`, migration_id: m.migrationId.toString(), result: m.step })),
    ],
    likely_cause: 'Likely cause (hypothesis): not assessed in template mode; review the trigger inputs and cooling status.',
    follow_ups: i.category === 'security'
      ? ['Rotate maintenance credentials.', 'Review all reads by the quarantined identity.']
      : failed.length ? ['Check the target rack health check that failed.', 'Confirm cooling for the source rack.'] : ['Confirm the cooling unit serving the source rack.'],
  };
}

export function templateShiftReport(incidents: Incident[]): ShiftReport {
  const order = { escalated: 0, open: 1, automated: 2, closed: 3 } as const;
  const sorted = [...incidents].sort((a, b) => order[a.status] - order[b.status]);
  const openCount = incidents.filter((i) => i.status !== 'closed').length;
  return {
    summary: `${incidents.length} incident${incidents.length === 1 ? '' : 's'} this shift; ${openCount} still open.`,
    incidents: sorted.map((i) => ({
      incident_id: i.incidentId.toString(),
      title: `${i.category === 'security' ? 'Security' : 'Thermal'} · ${i.rackId}`,
      status: i.status,
      note: `Trigger: ${i.triggerRule}. Owner: ${i.owner}.`,
    })),
    watch_next: openCount ? ['Open incidents listed above.'] : [],
  };
}
