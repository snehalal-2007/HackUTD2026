// Turns raw rows into the compact, numeric context the report is built from.
// The model never sees raw readings; it sees these summaries.
import type { Impact, IncidentContext, Migration } from './types.js';

export const hms = (ms: number) => new Date(ms).toISOString().slice(11, 19); // UTC HH:MM:SS

export function computeImpact(ctx: IncidentContext): Impact {
  const inlet = ctx.rollups.filter((r) => r.rackId === ctx.incident.rackId && r.metric === 'inlet_c');
  const peak = inlet.length ? Math.max(...inlet.map((r) => r.max)) : null;
  // Rollups are per minute: count a minute as "above 30" when its p95 is above 30,
  // and a partial minute when only its max is (estimate, stated as such in the report).
  const seconds = inlet.reduce((s, r) => s + (r.p95 >= 30 ? 60 : r.max >= 30 ? 30 : 0), 0);
  const moved = new Set(ctx.migrations.filter((m) => m.step === 'done').map((m) => m.serviceId)).size;
  return { peak_inlet_c: peak === null ? null : Math.round(peak * 10) / 10, seconds_above_30c: seconds, services_moved: moved, downtime_s: 0 };
}

/** Final state of each migration (rows are updated in place, but be tolerant of history rows). */
export function latestMigrations(ms: Migration[]): Migration[] {
  const byId = new Map<string, Migration>();
  for (const m of ms) {
    const k = m.migrationId.toString();
    const prev = byId.get(k);
    if (!prev || m.stepAt >= prev.stepAt) byId.set(k, m);
  }
  return [...byId.values()].sort((a, b) => a.stepAt - b.stepAt);
}

/** Compact JSON the model receives. Keep it small: tokens cost money and time. */
export function toPromptPayload(ctx: IncidentContext) {
  const i = ctx.incident;
  const perMinute = new Map<number, Record<string, number>>();
  for (const r of ctx.rollups.filter((r) => r.rackId === i.rackId)) {
    const row = perMinute.get(r.minute) ?? {};
    row[`${r.metric}_mean`] = round(r.mean);
    row[`${r.metric}_max`] = round(r.max);
    perMinute.set(r.minute, row);
  }
  return {
    incident: {
      id: i.incidentId.toString(), rack: i.rackId, category: i.category, severity: i.severity,
      status: i.status, trigger_rule: i.triggerRule, trigger_inputs: i.triggerInputs, owner: i.owner,
      opened: hms(i.openedAt), closed: i.closedAt ? hms(i.closedAt) : null,
    },
    impact: computeImpact(ctx),
    telemetry_per_minute: [...perMinute.entries()].sort((a, b) => a[0] - b[0]).map(([m, v]) => ({ minute: hms(m), ...v })),
    migrations: latestMigrations(ctx.migrations).map((m) => ({
      id: m.migrationId.toString(), service: m.serviceName, from: m.fromRack, to: m.toRack,
      result: m.step, at: hms(m.stepAt), reason: m.reason,
    })),
    log: ctx.log.slice(-40).map((e) => ({ at: hms(e.ts), actor: e.actor, action: e.action, target: e.target })),
  };
}

const round = (n: number) => Math.round(n * 10) / 10;
