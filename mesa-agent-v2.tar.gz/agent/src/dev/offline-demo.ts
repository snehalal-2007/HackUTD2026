// Runs the report pipeline on a realistic hot-rack incident WITHOUT SpacetimeDB.
// Use it tonight to tune prompts before the module is ready:
//   npm run demo:offline            (template mode if no ANTHROPIC_API_KEY)
import { writeIncidentReport, writeShiftReport } from '../llm.js';
import { describeConfig } from '../config.js';
import type { IncidentContext, Migration, Rollup } from '../types.js';

const T0 = Date.parse('2026-11-08T05:40:00Z');
const min = (m: number) => T0 + m * 60_000;

const rollups: Rollup[] = [];
const inlet = [25.1, 25.3, 25.2, 25.4, 25.6, 26.0, 27.1, 28.4, 29.6, 30.8, 31.2, 30.1, 28.6, 27.2, 26.4, 26.0];
inlet.forEach((v, k) => {
  const minute = min(k - 6);
  rollups.push({ rackId: 'B-04', minute, metric: 'inlet_c', min: v - 0.3, mean: v, max: v + 0.4, p95: v + 0.3 });
  rollups.push({ rackId: 'B-04', minute, metric: 'cpu_pct', min: 80, mean: k < 11 ? 86 : 58, max: k < 11 ? 91 : 63, p95: k < 11 ? 89 : 61 });
  rollups.push({ rackId: 'B-04', minute, metric: 'gpu_pct', min: 55, mean: k < 11 ? 61 : 34, max: k < 11 ? 66 : 39, p95: k < 11 ? 64 : 37 });
});

const mig = (id: number, svc: string, name: string, at: number): Migration =>
  ({ migrationId: BigInt(id), incidentId: 7n, serviceId: svc, serviceName: name, fromRack: 'B-04', toRack: 'C-02', step: 'done', stepAt: at, reason: 'migrate rule: inlet 30.8C, cpu 86%' });

const ctx: IncidentContext = {
  incident: {
    incidentId: 7n, rackId: 'B-04', category: 'thermal', severity: 'critical', status: 'closed',
    triggerRule: 'migrate', triggerInputs: { inlet_c: 30.8, cpu_pct: 86, gpu_pct: 61, held_s: 20, cooling_unit: 'CRAC-2' },
    owner: 'Adi', openedAt: min(1) + 20_000, closedAt: min(9) + 30_000,
  },
  rollups,
  migrations: [mig(31, 'svc-inference-a', 'inference-api', min(3) + 40_000), mig(32, 'svc-etl-2', 'etl-batch-2', min(4) + 10_000), mig(33, 'svc-cache-1', 'feature-cache', min(4) + 40_000)],
  log: [
    { seq: 101n, actor: 'rules', action: 'watch', target: 'B-04 inlet 28.4C', incidentId: 7n, ts: min(1) + 20_000 },
    { seq: 102n, actor: 'rules', action: 'migrate', target: 'B-04 → C-02 (score 0.31)', incidentId: 7n, ts: min(3) + 10_000 },
    { seq: 106n, actor: 'rules', action: 'recover', target: 'B-04 inlet 27.0C held 60 s', incidentId: 7n, ts: min(9) + 30_000 },
  ],
};

console.log(`[demo] ${describeConfig()}\n`);
const final = await writeIncidentReport(ctx, 'final');
console.log(`FINAL REPORT (source: ${final.source})\n` + JSON.stringify(final.report, null, 2));

const shift = await writeShiftReport([ctx.incident, { ...ctx.incident, incidentId: 8n, rackId: 'SECURITY', category: 'security', status: 'escalated', triggerRule: 'decoy_reducer', owner: 'Maya Okafor', closedAt: null }], [
  'rules migrate B-04 → C-02', 'honeypot decoy reducer called admin_override_alarm CRAC-1', 'guard rejected resolve_incident by quarantined identity',
]);
console.log(`\nSHIFT REPORT (source: ${shift.source})\n` + JSON.stringify(shift.report, null, 2));
