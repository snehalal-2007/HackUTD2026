// Shapes the agent reads and writes. They mirror docs/AGENT_HANDOFF.md section 4.
// Field names are camelCase as exposed by the generated SpacetimeDB bindings.

export type IncidentCategory = 'thermal' | 'security';
export type IncidentStatus = 'open' | 'automated' | 'escalated' | 'closed';
export type MigrationStep = 'plan' | 'warm' | 'sync' | 'switch' | 'drain' | 'done' | 'rolled_back';

/** Timestamps inside the agent are plain epoch milliseconds. */
export interface Incident {
  incidentId: bigint;
  rackId: string;                 // or 'SECURITY'
  category: IncidentCategory;
  severity: string;
  status: IncidentStatus;
  triggerRule: string;            // e.g. 'migrate', 'predicted', 'decoy_reducer'
  triggerInputs: Record<string, unknown>;
  owner: string;
  openedAt: number;
  closedAt: number | null;
}

export interface Migration {
  migrationId: bigint;
  incidentId: bigint;
  serviceId: string;
  serviceName: string;
  fromRack: string;
  toRack: string;
  step: MigrationStep;
  stepAt: number;
  reason: string;
}

export interface Rollup {
  rackId: string;
  minute: number;                 // epoch ms, floored to the minute
  metric: 'inlet_c' | 'cpu_pct' | 'gpu_pct';
  min: number; mean: number; max: number; p95: number;
}

export interface LogEntry { seq: bigint; actor: string; action: string; target: string; incidentId: bigint | null; ts: number }

/** Everything the agent is allowed to see for one incident. */
export interface IncidentContext {
  incident: Incident;
  rollups: Rollup[];              // 10 min before open → close
  migrations: Migration[];
  log: LogEntry[];
}

export interface Impact {
  peak_inlet_c: number | null;
  seconds_above_30c: number;
  services_moved: number;
  downtime_s: number;
}

/** The report the console renders. Fixed fields: nothing downstream parses free text. */
export interface IncidentReport {
  summary: string;
  impact: Impact;
  timeline: { ts: string; text: string }[];          // ts as HH:MM:SS
  automated_actions: { rule: string; inputs: string; migration_id: string | null; result: string }[];
  likely_cause: string;                              // always phrased as a hypothesis
  follow_ups: string[];                              // at most 3
}

export interface ShiftReport {
  summary: string;
  incidents: { incident_id: string; title: string; status: string; note: string }[];
  watch_next: string[];                              // at most 3
}

export type ReportSource = 'claude' | 'template';
