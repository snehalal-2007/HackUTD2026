// The ONLY file that knows the generated SpacetimeDB bindings.
// If a table, field or reducer name differs in packages/bindings, fix it here and nowhere else.
//
// Assumptions to check against `spacetime generate` output for our SDK version:
//   - DbConnection.builder().withUri().withModuleName().withToken().onConnect().build()
//     (newer SDKs may call withModuleName `withDatabaseName`)
//   - conn.db.<table>.iter(), .onInsert(cb), .onUpdate(cb)
//   - conn.reducers.<camelName>({ ...args })
//   - Timestamps arrive as SpacetimeDB Timestamp objects; toMs() handles the common shapes.

// @ts-ignore — path exists in the monorepo after bindings are generated
import { DbConnection } from '../../../packages/bindings/index.js';
import type { Incident, LogEntry, Migration, Rollup } from './types.js';

export type Conn = any; // the generated DbConnection type; `any` keeps this file compiling before bindings exist

export function toMs(t: any): number {
  if (t == null) return 0;
  if (typeof t === 'number') return t;
  if (typeof t === 'bigint') return Number(t / 1000n);                         // micros → ms
  if (typeof t.toMillis === 'function') return Number(t.toMillis());
  if (typeof t.toDate === 'function') return t.toDate().getTime();
  if ('microsSinceUnixEpoch' in t) return Number(BigInt(t.microsSinceUnixEpoch) / 1000n);
  if ('__timestamp_micros_since_unix_epoch__' in t) return Number(BigInt(t.__timestamp_micros_since_unix_epoch__) / 1000n);
  return 0;
}

const opt = (v: any) => (v && typeof v === 'object' && 'tag' in v ? (v.tag === 'some' ? v.value : null) : v ?? null);

export function mapIncident(r: any): Incident {
  let inputs: Record<string, unknown> = {};
  try { inputs = JSON.parse(r.triggerInputs || '{}'); } catch { inputs = { raw: String(r.triggerInputs) }; }
  return {
    incidentId: BigInt(r.incidentId), rackId: r.rackId, category: (r.category?.tag ?? r.category) as any,
    severity: r.severity?.tag ?? r.severity, status: (r.status?.tag ?? r.status) as any,
    triggerRule: r.triggerRule, triggerInputs: inputs, owner: r.ownerName ?? String(r.owner ?? ''),
    openedAt: toMs(r.openedAt), closedAt: opt(r.closedAt) ? toMs(opt(r.closedAt)) : null,
  };
}

export function mapMigration(r: any, serviceName: (id: string) => string): Migration {
  return {
    migrationId: BigInt(r.migrationId), incidentId: BigInt(r.incidentId), serviceId: r.serviceId,
    serviceName: serviceName(r.serviceId), fromRack: r.fromRack, toRack: r.toRack,
    step: (r.step?.tag ?? r.step) as any, stepAt: toMs(r.stepAt), reason: r.reason ?? '',
  };
}

export function mapRollup(r: any): Rollup {
  return { rackId: r.rackId, minute: toMs(r.minute), metric: r.metric?.tag ?? r.metric, min: r.min, mean: r.mean, max: r.max, p95: r.p95 };
}

export function mapLog(r: any): LogEntry {
  const inc = opt(r.incidentId);
  return { seq: BigInt(r.seq), actor: r.actor, action: r.action, target: r.target, incidentId: inc == null ? null : BigInt(inc), ts: toMs(r.ts) };
}

export interface Handlers {
  onIncident: (row: any) => void;
  onShift: (row: any) => void;
  onReady: () => void;
}

export function connect(opts: { host: string; db: string; token?: string }, h: Handlers): void {
  DbConnection.builder()
    .withUri(opts.host)
    .withModuleName(opts.db)
    .withToken(opts.token)
    .onConnect((conn: Conn, identity: any, token: string) => {
      console.log(`[agent] connected as ${identity.toHexString()}`);
      if (!opts.token) console.log('[agent] Save this as STDB_AGENT_TOKEN and give the identity above to the module owner for the agent allow-list:\n' + token);
      current = conn;
      conn.db.incident.onInsert((_c: any, row: any) => h.onIncident(row));
      conn.db.incident.onUpdate((_c: any, _old: any, row: any) => h.onIncident(row));
      conn.db.shift.onUpdate((_c: any, _old: any, row: any) => h.onShift(row));
      conn.subscriptionBuilder()
        .onApplied(() => h.onReady())
        .subscribe([
          'SELECT * FROM incident', 'SELECT * FROM migration', 'SELECT * FROM telemetry_rollup',
          'SELECT * FROM event_log', 'SELECT * FROM shift', 'SELECT * FROM service',
          'SELECT * FROM incident_report', 'SELECT * FROM shift_report',
        ]);
    })
    .onConnectError((_c: any, err: unknown) => { console.error('[agent] connect failed', err); process.exit(1); })
    .onDisconnect(() => { console.error('[agent] disconnected; exiting so the host restarts us'); process.exit(1); })
    .build();
}

let current: Conn = null;
export const conn = () => current;

// ---- reads ----
export const allIncidents = (): Incident[] => [...current.db.incident.iter()].map(mapIncident);
export const hasIncidentReport = (id: bigint, kind: 'final' | 'interim') =>
  [...current.db.incidentReport.iter()].some((r: any) => BigInt(r.incidentId) === id && (r.kind?.tag ?? r.kind) === kind);
export const hasShiftReport = (shiftId: bigint) => [...current.db.shiftReport.iter()].some((r: any) => BigInt(r.shiftId) === shiftId);

export function serviceNameLookup(): (id: string) => string {
  const m = new Map<string, string>();
  for (const s of current.db.service.iter()) m.set(s.serviceId, s.name);
  return (id) => m.get(id) ?? id;
}
export const migrationsFor = (id: bigint) => {
  const name = serviceNameLookup();
  return [...current.db.migration.iter()].filter((r: any) => BigInt(r.incidentId) === id).map((r: any) => mapMigration(r, name));
};
export const rollupsFor = (rackId: string, fromMs: number, toMs_: number) =>
  [...current.db.telemetryRollup.iter()].map(mapRollup).filter((r) => r.rackId === rackId && r.minute >= fromMs && r.minute <= toMs_);
export const logFor = (id: bigint) => [...current.db.eventLog.iter()].map(mapLog).filter((e) => e.incidentId === id).sort((a, b) => Number(a.seq - b.seq));
export const recentLogLines = (n = 60) =>
  [...current.db.eventLog.iter()].map(mapLog).sort((a, b) => Number(a.seq - b.seq)).slice(-n).map((e) => `${e.actor} ${e.action} ${e.target}`);

// ---- writes (the agent's entire write surface) ----
export function attachReport(incidentId: bigint, kind: 'final' | 'interim', reportJson: string, source: string) {
  current.reducers.attachReport({ incidentId, kind, reportJson, source });
}
export function attachShiftReport(shiftId: bigint, reportJson: string, source: string) {
  current.reducers.attachShiftReport({ shiftId, reportJson, source });
}
