// Reads settings from the environment. The API key is never logged.

const num = (v: string | undefined, d: number) => (v && !Number.isNaN(Number(v)) ? Number(v) : d);

export const config = {
  apiKey: process.env.ANTHROPIC_API_KEY?.trim() || '',
  model: process.env.CLAUDE_MODEL || 'claude-haiku-5-5',
  stdbHost: process.env.STDB_HOST || 'ws://localhost:3000',
  stdbDb: process.env.STDB_DB || 'mesa',
  stdbToken: process.env.STDB_AGENT_TOKEN || undefined,
  llmTimeoutMs: num(process.env.LLM_TIMEOUT_MS, 8000),
  maxLlmCallsPerMin: num(process.env.MAX_LLM_CALLS_PER_MIN, 20),
};

/** Without a key the agent still works: every report comes from the template. */
export const llmEnabled = config.apiKey.length > 0;

export function describeConfig() {
  return `model=${config.model} llm=${llmEnabled ? 'on' : 'off (template mode)'} db=${config.stdbHost}/${config.stdbDb}`;
}
